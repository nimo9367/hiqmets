class Entry {
    public aid?: string;
    public cid?: string;
    public uid?: string;
    public kcal?: number;
    public created?: Date;
    public minutes?: number;
    public stravaId?: string;
}
export default Entry;