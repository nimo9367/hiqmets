<template>
  <div>
    <div class="hero is-light">
      <div class="hero-body">
        <div class="container">
          <h1 class="title">
            Tillgängliga utmaningar 
          </h1>
          <h2 class="subtitle">
            En lista med kommande, pågående och avslutade tävlingar
          </h2>
        </div>
      </div>
    </div>
    <div>
      <div class="container">
        <section class="section">
        <p>Just nu finns det endast en registrerad tävling</p>
        </section>
      </div>
    </div>
  </div>  
</template>
