<template>
  <div>
    <div class="hero is-light">
      <div class="hero-body">
        <div v-if="challange" class="container">
          <h1 class="title">
            {{ challange.name }}
          </h1>
          <h2 class="subtitle">
            Slutar om: {{ challange.countDownStr }}
          </h2>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="section">
        <div class="columns">
          <div class="column  is-one-quarter">
            <RegisterActivity></RegisterActivity>
          </div>
          <div class="column auto">
            <nav class="level">
              <p class="level-item has-text-centered">
                <a class="link is-info" @click="filterActivities('')">Alla</a>
              </p>
              <p class="level-item has-text-centered">
                <a class="link is-info" @click="filterActivities('run')">Löpning</a>
              </p>
              <p class="level-item has-text-centered">
                <span class="icon has-text-warning">
                  <i class="fas fa-star"></i>
                </span>
                
                <span class="icon has-text-warning">
                  <i class="fas fa-star fa-2x"></i>
                </span>
                
                <span class="icon has-text-warning">
                  <i class="fas fa-star"></i>
                </span>
              </p>
              <p class="level-item has-text-centered">
                <a class="link is-info" @click="filterActivities('cycle')">Cykling</a>
              </p>
              <p class="level-item has-text-centered">
                <a class="link is-info" @click="filterActivities('misc')">Övriga</a>
              </p>
            </nav>
            <div class="tags ">
              <span v-for="act in filteredActivities" v-bind:key="act" class="tag is-light">
                {{act}}
              </span>
            </div>
            <div class="card">
              <div class="card-content">
                <div class="columns is-vcentered is-mobile" v-for="stats in userData.statsData.userStats" v-bind:key="stats.uid" >
                  <div class="column is-one-fifth has-text-right">
                    <a href="#"><router-link :to="{ name: 'ActivityList', params: {userId: stats.uid } }">
                      <div class="columns is-vcentered is-mobile">
                        <div class="column">
                          <h1 class="is-vcentered">{{stats.name}}</h1>
                        </div>
                        <div class="column is-narrow">
                          <figure class="image is-32x32" >
                            <img class="is-rounded" v-bind:src="'https://api.adorable.io/avatars/100/' + stats.uid + '.png'">
                          </figure>
                        </div>
                      </div>
                      </router-link>
                    </a>
                  </div>
                  <div class="column is-three-fifth ">
                      <progress class="progress is-primary is-large " v-bind:value="(stats.totalPoints / max) * 100" max="100">100%</progress>
                  </div>
                  <div class="column is-one-fifth">
                    <h1>{{stats.totalPoints}} Poäng</h1>
                  </div>
                </div>
              </div>
              <footer class="card-footer">
                <p class="card-footer-item">
                  <span>
                  </span>
                </p>
                <p class="card-footer-item">
                  <span>
                    Totalt  <b>{{total.kcal}} </b> Kcal
                  </span>
                </p>
              </footer>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import Activities from '@/components/Activities.vue'; // @ is an alias to /src
import RegisterActivity from '@/components/RegisterActivity.vue'; 
import firebase from 'firebase';
import { db, userData } from '../main';

Vue.component('RegisterActivity', RegisterActivity);

@Component
export default class Home extends Vue {
  data() {
    return {
      name: userData.user.name,
      challange: userData.challange,
      userData: userData
    };
  }
  get total() {
    if(userData.statsData.userStats.length < 2)
      return 1;
    var totMinutes = userData.statsData.userStats.map((x:any) => x.totalTime).reduce((a: any, b: any) => a + b);
    
    var totKcal = userData.statsData.userStats.map((x:any) => x.totalKcal).reduce((a: any, b: any) => a + b);
    return { kcal: totKcal, minutes: totMinutes };
  }
  get max() {
    if(userData.statsData.userStats.length < 2)
      return 1;
    const max = userData.statsData.userStats.map((x:any) => x.totalPoints).reduce((a: any, b: any) => {
        return Math.max(a, b);
    });
    return max > 0 ? max : 1;
  }

  get filteredActivities() {
    return userData.activities.map(x => x.text)
      .filter(x => this.runOnly ? x.indexOf('Löpning') == 0 : (this.cycleOnly ? x.indexOf('Cykling') == 0 : (this.miscOnly ? x.indexOf('Löpning') == -1 && x.indexOf('Cykling') == -1 : false)));
  }
  runOnly = false;
  cycleOnly = false;
  miscOnly = false;
  filterActivities(filter: string) {
    if(filter == 'run') {
      this.runOnly = true;
      this.cycleOnly = false;
      this.miscOnly = false;
    }
    else if(filter == 'cycle') {
      this.runOnly = false;
      this.cycleOnly = true;
      this.miscOnly = false;
    }
    else if(filter == 'misc') {
      this.runOnly = false;
      this.cycleOnly = false;
      this.miscOnly = true;
    }
    else {
      this.runOnly = false;
      this.cycleOnly = false;
      this.miscOnly = false;
    }

  }

  @Watch('userData.challange')
  callangeChange() {
    debugger;
    userData.loadStats();
  }
}
</script>
