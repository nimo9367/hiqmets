class User {
    public id: string = '';
    public email: string = '';
    public name: string = '';
    public length: number = 0;
    public weight: number = 0;
    public sex: string = '';
    public favoriteActivity: string = '';
    public default_challange: string = '';
}

export default User;
